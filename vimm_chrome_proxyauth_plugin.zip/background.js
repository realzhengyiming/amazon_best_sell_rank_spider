
			var config = {
					mode: "fixed_servers",
					rules: {
					singleProxy: {
						scheme: "http",
						host: "r847.kdltps.com",
						port: parseInt(15818)
					},
					bypassList: ["foobar.com"]
					}
				};

			chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

			function callbackFn(details) {
				return {
					authCredentials: {
						username: "t18533708977798",
						password: "ukoaa3t8"
					}
				};
			}

			chrome.webRequest.onAuthRequired.addListener(
						callbackFn,
						{urls: ["<all_urls>"]},
						['blocking']
			);
			